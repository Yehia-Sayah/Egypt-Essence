// Egypt Essence Tours - Complete Multilingual Interactive Application
// Supporting 7 languages with automatic detection and updated contact information

document.addEventListener('DOMContentLoaded', function() {
    
    // Multilingual Content Database - Complete translations for all 7 languages
    const translations = {
        ar: {
            // Page Meta
            'page-title': 'Egypt Essence Tours - اكتشف جوهر مصر الحقيقي',
            'page-description': 'أفضل الرحلات السياحية في مصر - الغردقة، الأقصر، والقاهرة. احجز رحلتك الآن!',
            
            // Company Info
            'company-name': 'Egypt Essence Tours',
            'company-tagline': 'اكتشف جوهر مصر الحقيقي',
            
            // Navigation
            'nav-home': 'الرئيسية',
            'nav-hurghada': 'رحلات الغردقة',
            'nav-luxor': 'رحلات الأقصر',
            'nav-cairo': 'رحلات القاهرة',
            'nav-about': 'من نحن',
            'nav-contact': 'التواصل',
            
            // Hero Section
            'hero-title': 'اكتشف سحر مصر معنا',
            'hero-subtitle': 'استمتع بأجمل الرحلات السياحية في الغردقة والأقصر والقاهرة',
            'hero-cta': 'ابدأ رحلتك الآن',
            
            // About Section
            'about-title': 'من نحن',
            'about-subtitle': 'شركة Egypt Essence Tours، رفيقك المثالي لاستكشاف جمال مصر',
            'about-description': 'نحن شركة متخصصة في تنظيم الرحلات السياحية في أجمل المدن المصرية. نقدم خدمات متميزة ورحلات منظمة بعناية لضمان حصولكم على أفضل تجربة سياحية ممكنة.',
            'feature-service': 'خدمة عملاء متميزة',
            'feature-safety': 'رحلات آمنة ومؤمنة',
            'feature-guides': 'مرشدين سياحيين محترفين',
            'feature-timing': 'مواعيد دقيقة ومنظمة',
            
            // Tours and other content (keeping existing Arabic content)
            'hurghada-title': 'رحلات الغردقة',
            'hurghada-subtitle': 'استمتع بمغامرات البحر الأحمر الرائعة',
            'luxor-title': 'رحلات الأقصر',
            'luxor-subtitle': 'اكتشف كنوز مصر الفرعونية',
            'cairo-title': 'رحلات القاهرة',
            'cairo-subtitle': 'اكتشف عجائب مصر القديمة',
            
            // Tours (keeping existing)
            'tour-hula-hula-name': 'رحلة جزيرة هولا هولا',
            'tour-hula-hula-time': '8:30 صباحاً - 4:30 مساءً',
            'tour-hula-hula-desc': 'استمتع بالمالديف المصرية مع المياه الصافية والشواطئ الذهبية ونقاط تصوير احترافية',
            'tour-hula-hula-h1': 'محطتان للغطس',
            'tour-hula-hula-h2': 'استكشاف الجزيرة',
            'tour-hula-hula-h3': 'غداء شامل',
            'tour-hula-hula-h4': 'سترات نجاة متوفرة',
            
            'book-now': 'احجز الآن',
            
            // Contact Section
            'contact-title': 'تواصل معنا',
            'contact-subtitle': 'نحن هنا لمساعدتك في التخطيط لرحلة أحلامك',
            'contact-whatsapp': 'واتس اب',
            'contact-email': 'البريد الإلكتروني',
            'contact-phone': 'الهاتف',
            'form-name': 'اسمك الكامل',
            'form-email': 'البريد الإلكتروني',
            'form-phone': 'رقم الهاتف',
            'form-message': 'رسالتك أو استفسارك',
            'form-submit': 'أرسل الرسالة',
            
            // Footer
            'footer-links': 'روابط سريعة',
            'footer-social': 'تابعنا',
            'footer-copyright': '© 2025 Egypt Essence Tours. جميع الحقوق محفوظة.',
            
            // WhatsApp Messages
            'whatsapp-general': 'مرحباً! أريد الاستفسار عن رحلاتكم السياحية',
            'whatsapp-contact-form': 'مرحباً! اسمي {name}، بريدي الإلكتروني: {email}، هاتفي: {phone}. رسالتي: {message}'
        },
        
        en: {
            // Page Meta
            'page-title': 'Egypt Essence Tours - Discover the True Essence of Egypt',
            'page-description': 'Best tours in Egypt - Hurghada, Luxor, and Cairo. Book your trip now!',
            
            // Company Info
            'company-name': 'Egypt Essence Tours',
            'company-tagline': 'Discover the True Essence of Egypt',
            
            // Navigation
            'nav-home': 'Home',
            'nav-hurghada': 'Hurghada Tours',
            'nav-luxor': 'Luxor Tours',
            'nav-cairo': 'Cairo Tours',
            'nav-about': 'About Us',
            'nav-contact': 'Contact',
            
            // Hero Section
            'hero-title': 'Discover Egypt\'s Magic with Us',
            'hero-subtitle': 'Enjoy the most beautiful tours in Hurghada, Luxor and Cairo',
            'hero-cta': 'Start Your Journey Now',
            
            // About Section
            'about-title': 'About Us',
            'about-subtitle': 'Egypt Essence Tours, your perfect companion to explore Egypt\'s beauty',
            'about-description': 'We are a specialized company organizing tours in Egypt\'s most beautiful cities. We provide excellent services and carefully organized trips to ensure you have the best possible tourist experience.',
            'feature-service': 'Excellent Customer Service',
            'feature-safety': 'Safe and Secure Tours',
            'feature-guides': 'Professional Tour Guides',
            'feature-timing': 'Punctual and Organized',
            
            // Sections
            'hurghada-title': 'Hurghada Tours',
            'hurghada-subtitle': 'Enjoy amazing Red Sea adventures',
            'luxor-title': 'Luxor Tours',
            'luxor-subtitle': 'Discover Egypt\'s Pharaonic treasures',
            'cairo-title': 'Cairo Tours',
            'cairo-subtitle': 'Discover the wonders of ancient Egypt',
            
            // Tours
            'tour-hula-hula-name': 'Hula Hula Island Trip',
            'tour-hula-hula-time': '8:30 AM - 4:30 PM',
            'tour-hula-hula-desc': 'Experience Egyptian Maldives with crystal-clear waters and golden beaches with professional photo spots',
            'tour-hula-hula-h1': 'Two snorkeling stops',
            'tour-hula-hula-h2': 'Island exploration',
            'tour-hula-hula-h3': 'Full lunch included',
            'tour-hula-hula-h4': 'Life jackets available',
            
            'book-now': 'Book Now',
            
            // Contact Section
            'contact-title': 'Contact Us',
            'contact-subtitle': 'We\'re here to help you plan your dream trip',
            'contact-whatsapp': 'WhatsApp',
            'contact-email': 'Email',
            'contact-phone': 'Phone',
            'form-name': 'Your Full Name',
            'form-email': 'Email Address',
            'form-phone': 'Phone Number',
            'form-message': 'Your Message or Inquiry',
            'form-submit': 'Send Message',
            
            // Footer
            'footer-links': 'Quick Links',
            'footer-social': 'Follow Us',
            'footer-copyright': '© 2025 Egypt Essence Tours. All rights reserved.',
            
            // WhatsApp Messages
            'whatsapp-general': 'Hello! I would like to inquire about your tours',
            'whatsapp-contact-form': 'Hello! My name is {name}, email: {email}, phone: {phone}. Message: {message}'
        },
        
        de: {
            // Page Meta
            'page-title': 'Egypt Essence Tours - Entdecke die wahre Essenz Ägyptens',
            'page-description': 'Beste Touren in Ägypten - Hurghada, Luxor und Kairo. Buchen Sie jetzt Ihre Reise!',
            
            // Company Info
            'company-name': 'Egypt Essence Tours',
            'company-tagline': 'Entdecke die wahre Essenz Ägyptens',
            
            // Navigation
            'nav-home': 'Startseite',
            'nav-hurghada': 'Hurghada Touren',
            'nav-luxor': 'Luxor Touren',
            'nav-cairo': 'Kairo Touren',
            'nav-about': 'Über Uns',
            'nav-contact': 'Kontakt',
            
            // Hero Section
            'hero-title': 'Entdecke Ägyptens Magie mit uns',
            'hero-subtitle': 'Genieße die schönsten Touren in Hurghada, Luxor und Kairo',
            'hero-cta': 'Starte deine Reise jetzt',
            
            // About Section
            'about-title': 'Über Uns',
            'about-subtitle': 'Egypt Essence Tours, Ihr perfekter Begleiter zur Erkundung Ägyptens Schönheit',
            'about-description': 'Wir sind ein spezialisiertes Unternehmen, das Touren in Ägyptens schönsten Städten organisiert. Wir bieten exzellente Dienstleistungen und sorgfältig organisierte Reisen, um Ihnen die bestmögliche Touristen erfahrung zu gewährleisten.',
            'feature-service': 'Exzellenter Kundenservice',
            'feature-safety': 'Sichere Touren',
            'feature-guides': 'Professionelle Reiseführer',
            'feature-timing': 'Pünktlich und organisiert',
            
            // Sections
            'hurghada-title': 'Hurghada Touren',
            'hurghada-subtitle': 'Genieße erstaunliche Rotes Meer Abenteuer',
            'luxor-title': 'Luxor Touren',
            'luxor-subtitle': 'Entdecke Ägyptens pharaonische Schätze',
            'cairo-title': 'Kairo Touren',
            'cairo-subtitle': 'Entdecke die Wunder des alten Ägyptens',
            
            // Tours
            'tour-hula-hula-name': 'Hula Hula Inselausflug',
            'tour-hula-hula-time': '8:30 - 16:30 Uhr',
            'tour-hula-hula-desc': 'Erleben Sie die ägyptischen Malediven mit kristallklarem Wasser und goldenen Stränden mit professionellen Fotospots',
            'tour-hula-hula-h1': 'Zwei Schnorchelstopps',
            'tour-hula-hula-h2': 'Inselerkundung',
            'tour-hula-hula-h3': 'Vollständiges Mittagessen',
            'tour-hula-hula-h4': 'Schwimmwesten verfügbar',
            
            'book-now': 'Jetzt Buchen',
            
            // Contact Section
            'contact-title': 'Kontaktieren Sie uns',
            'contact-subtitle': 'Wir helfen Ihnen bei der Planung Ihrer Traumreise',
            'contact-whatsapp': 'WhatsApp',
            'contact-email': 'E-Mail',
            'contact-phone': 'Telefon',
            'form-name': 'Ihr vollständiger Name',
            'form-email': 'E-Mail-Adresse',
            'form-phone': 'Telefonnummer',
            'form-message': 'Ihre Nachricht oder Anfrage',
            'form-submit': 'Nachricht senden',
            
            // Footer
            'footer-links': 'Schnelle Links',
            'footer-social': 'Folgen Sie uns',
            'footer-copyright': '© 2025 Egypt Essence Tours. Alle Rechte vorbehalten.',
            
            // WhatsApp Messages
            'whatsapp-general': 'Hallo! Ich möchte mich über Ihre Touren informieren',
            'whatsapp-contact-form': 'Hallo! Mein Name ist {name}, E-Mail: {email}, Telefon: {phone}. Nachricht: {message}'
        },
        
        ru: {
            // Page Meta
            'page-title': 'Egypt Essence Tours - Откройте истинную суть Египта',
            'page-description': 'Лучшие туры в Египте - Хургада, Луксор и Каир. Забронируйте поездку сейчас!',
            
            // Company Info
            'company-name': 'Egypt Essence Tours',
            'company-tagline': 'Откройте истинную суть Египта',
            
            // Navigation
            'nav-home': 'Главная',
            'nav-hurghada': 'Туры в Хургаду',
            'nav-luxor': 'Туры в Луксор',
            'nav-cairo': 'Туры в Каир',
            'nav-about': 'О нас',
            'nav-contact': 'Контакты',
            
            // Hero Section
            'hero-title': 'Откройте магию Египта с нами',
            'hero-subtitle': 'Наслаждайтесь самыми красивыми турами в Хургаде, Луксоре и Каире',
            'hero-cta': 'Начните свое путешествие сейчас',
            
            // About Section
            'about-title': 'О нас',
            'about-subtitle': 'Egypt Essence Tours, ваш идеальный спутник для изучения красоты Египта',
            'about-description': 'Мы специализированная компания, организующая туры в самые красивые города Египта. Мы предоставляем отличные услуги и тщательно организованные поездки, чтобы обеспечить вам лучший возможный туристический опыт.',
            'feature-service': 'Отличное обслуживание клиентов',
            'feature-safety': 'Безопасные туры',
            'feature-guides': 'Профессиональные гиды',
            'feature-timing': 'Пунктуально и организованно',
            
            // Sections
            'hurghada-title': 'Туры в Хургаду',
            'hurghada-subtitle': 'Наслаждайтесь удивительными приключениями Красного моря',
            'luxor-title': 'Туры в Луксор',
            'luxor-subtitle': 'Откройте фараонские сокровища Египта',
            'cairo-title': 'Туры в Каир',
            'cairo-subtitle': 'Откройте чудеса древнего Египта',
            
            // Tours
            'tour-hula-hula-name': 'Поездка на остров Хула Хула',
            'tour-hula-hula-time': '8:30 - 16:30',
            'tour-hula-hula-desc': 'Испытайте египетские Мальдивы с кристально чистой водой и золотыми пляжами с профессиональными фотозонами',
            'tour-hula-hula-h1': 'Две остановки для снорклинга',
            'tour-hula-hula-h2': 'Исследование острова',
            'tour-hula-hula-h3': 'Полный обед включен',
            'tour-hula-hula-h4': 'Спасательные жилеты в наличии',
            
            'book-now': 'Забронировать сейчас',
            
            // Contact Section
            'contact-title': 'Свяжитесь с нами',
            'contact-subtitle': 'Мы здесь, чтобы помочь вам спланировать поездку мечты',
            'contact-whatsapp': 'WhatsApp',
            'contact-email': 'Электронная почта',
            'contact-phone': 'Телефон',
            'form-name': 'Ваше полное имя',
            'form-email': 'Адрес электронной почты',
            'form-phone': 'Номер телефона',
            'form-message': 'Ваше сообщение или запрос',
            'form-submit': 'Отправить сообщение',
            
            // Footer
            'footer-links': 'Быстрые ссылки',
            'footer-social': 'Следуйте за нами',
            'footer-copyright': '© 2025 Egypt Essence Tours. Все права защищены.',
            
            // WhatsApp Messages
            'whatsapp-general': 'Привет! Я хотел бы узнать о ваших турах',
            'whatsapp-contact-form': 'Привет! Меня зовут {name}, электронная почта: {email}, телефон: {phone}. Сообщение: {message}'
        },
        
        zh: {
            // Page Meta
            'page-title': 'Egypt Essence Tours - 探索埃及的真正精髓',
            'page-description': '埃及最佳旅游 - 赫尔格达、卢克索和开罗。立即预订您的旅行！',
            
            // Company Info
            'company-name': 'Egypt Essence Tours',
            'company-tagline': '探索埃及的真正精髓',
            
            // Navigation
            'nav-home': '首页',
            'nav-hurghada': '赫尔格达旅游',
            'nav-luxor': '卢克索旅游',
            'nav-cairo': '开罗旅游',
            'nav-about': '关于我们',
            'nav-contact': '联系我们',
            
            // Hero Section
            'hero-title': '与我们一起探索埃及的魔力',
            'hero-subtitle': '享受在赫尔格达、卢克索和开罗最美丽的旅游',
            'hero-cta': '立即开始您的旅程',
            
            // About Section
            'about-title': '关于我们',
            'about-subtitle': 'Egypt Essence Tours，您探索埃及美景的完美伴侣',
            'about-description': '我们是一家专门在埃及最美丽城市组织旅游的公司。我们提供优质服务和精心组织的旅行，确保您获得最佳的旅游体验。',
            'feature-service': '优质客户服务',
            'feature-safety': '安全可靠的旅游',
            'feature-guides': '专业导游',
            'feature-timing': '准时有序',
            
            // Sections
            'hurghada-title': '赫尔格达旅游',
            'hurghada-subtitle': '享受令人惊叹的红海冒险',
            'luxor-title': '卢克索旅游',
            'luxor-subtitle': '发现埃及的法老宝藏',
            'cairo-title': '开罗旅游',
            'cairo-subtitle': '发现古埃及的奇迹',
            
            // Tours
            'tour-hula-hula-name': '呼拉呼拉岛之旅',
            'tour-hula-hula-time': '上午8:30 - 下午4:30',
            'tour-hula-hula-desc': '体验埃及马尔代夫，享受清澈的海水和金色海滩以及专业摄影点',
            'tour-hula-hula-h1': '两个浮潜点',
            'tour-hula-hula-h2': '岛屿探索',
            'tour-hula-hula-h3': '包含午餐',
            'tour-hula-hula-h4': '提供救生衣',
            
            'book-now': '立即预订',
            
            // Contact Section
            'contact-title': '联系我们',
            'contact-subtitle': '我们在这里帮助您计划梦想之旅',
            'contact-whatsapp': 'WhatsApp',
            'contact-email': '电子邮件',
            'contact-phone': '电话',
            'form-name': '您的全名',
            'form-email': '电子邮件地址',
            'form-phone': '电话号码',
            'form-message': '您的信息或询问',
            'form-submit': '发送信息',
            
            // Footer
            'footer-links': '快速链接',
            'footer-social': '关注我们',
            'footer-copyright': '© 2025 Egypt Essence Tours。版权所有。',
            
            // WhatsApp Messages
            'whatsapp-general': '您好！我想咨询您的旅游项目',
            'whatsapp-contact-form': '您好！我的名字是{name}，邮箱：{email}，电话：{phone}。信息：{message}'
        },
        
        cs: {
            // Page Meta
            'page-title': 'Egypt Essence Tours - Objevte pravou podstatu Egypta',
            'page-description': 'Nejlepší výlety v Egyptě - Hurghada, Luxor a Káhira. Rezervujte si výlet hned teď!',
            
            // Company Info
            'company-name': 'Egypt Essence Tours',
            'company-tagline': 'Objevte pravou podstatu Egypta',
            
            // Navigation
            'nav-home': 'Domů',
            'nav-hurghada': 'Výlety do Hurghady',
            'nav-luxor': 'Výlety do Luxoru',
            'nav-cairo': 'Výlety do Káhiry',
            'nav-about': 'O nás',
            'nav-contact': 'Kontakt',
            
            // Hero Section
            'hero-title': 'Objevte kouzlo Egypta s námi',
            'hero-subtitle': 'Užijte si nejkrásnější výlety v Hurghadě, Luxoru a Káhiře',
            'hero-cta': 'Začněte svou cestu nyní',
            
            // About Section
            'about-title': 'O nás',
            'about-subtitle': 'Egypt Essence Tours, váš dokonalý společník pro objevování krásy Egypta',
            'about-description': 'Jsme specializovaná společnost organizující výlety v nejkrásnějších městech Egypta. Poskytujeme vynikající služby a pečlivě organizované výlety, abychom vám zajistili nejlepší možný turistický zážitek.',
            'feature-service': 'Vynikající zákaznický servis',
            'feature-safety': 'Bezpečné výlety',
            'feature-guides': 'Profesionální průvodci',
            'feature-timing': 'Přesné a organizované',
            
            // Sections
            'hurghada-title': 'Výlety do Hurghady',
            'hurghada-subtitle': 'Užijte si úžasná dobrodružství Rudého moře',
            'luxor-title': 'Výlety do Luxoru',
            'luxor-subtitle': 'Objevte faraónské poklady Egypta',
            'cairo-title': 'Výlety do Káhiry',
            'cairo-subtitle': 'Objevte divy starověkého Egypta',
            
            // Tours
            'tour-hula-hula-name': 'Výlet na ostrov Hula Hula',
            'tour-hula-hula-time': '8:30 - 16:30',
            'tour-hula-hula-desc': 'Zažijte egyptské Maledivy s křišťálově čistou vodou a zlatými plážemi s profesionálními fotografickými místy',
            'tour-hula-hula-h1': 'Dvě zastávky pro šnorchlování',
            'tour-hula-hula-h2': 'Průzkum ostrova',
            'tour-hula-hula-h3': 'Oběd v ceně',
            'tour-hula-hula-h4': 'Záchranné vesty k dispozici',
            
            'book-now': 'Rezervovat nyní',
            
            // Contact Section
            'contact-title': 'Kontaktujte nás',
            'contact-subtitle': 'Jsme tu, abychom vám pomohli naplánovat vaši vysněnou cestu',
            'contact-whatsapp': 'WhatsApp',
            'contact-email': 'E-mail',
            'contact-phone': 'Telefon',
            'form-name': 'Vaše celé jméno',
            'form-email': 'E-mailová adresa',
            'form-phone': 'Telefonní číslo',
            'form-message': 'Vaše zpráva nebo dotaz',
            'form-submit': 'Odeslat zprávu',
            
            // Footer
            'footer-links': 'Rychlé odkazy',
            'footer-social': 'Sledujte nás',
            'footer-copyright': '© 2025 Egypt Essence Tours. Všechna práva vyhrazena.',
            
            // WhatsApp Messages
            'whatsapp-general': 'Ahoj! Chtěl bych se zeptat na vaše výlety',
            'whatsapp-contact-form': 'Ahoj! Jmenuji se {name}, e-mail: {email}, telefon: {phone}. Zpráva: {message}'
        },
        
        fr: {
            // Page Meta
            'page-title': 'Egypt Essence Tours - Découvrez la vraie essence de l\'Égypte',
            'page-description': 'Meilleurs circuits en Égypte - Hurghada, Luxor et Le Caire. Réservez votre voyage maintenant!',
            
            // Company Info
            'company-name': 'Egypt Essence Tours',
            'company-tagline': 'Découvrez la vraie essence de l\'Égypte',
            
            // Navigation
            'nav-home': 'Accueil',
            'nav-hurghada': 'Circuits Hurghada',
            'nav-luxor': 'Circuits Luxor',
            'nav-cairo': 'Circuits Le Caire',
            'nav-about': 'À propos',
            'nav-contact': 'Contact',
            
            // Hero Section
            'hero-title': 'Découvrez la magie de l\'Égypte avec nous',
            'hero-subtitle': 'Profitez des plus beaux circuits à Hurghada, Luxor et Le Caire',
            'hero-cta': 'Commencez votre voyage maintenant',
            
            // About Section
            'about-title': 'À propos de nous',
            'about-subtitle': 'Egypt Essence Tours, votre compagnon parfait pour explorer la beauté de l\'Égypte',
            'about-description': 'Nous sommes une entreprise spécialisée dans l\'organisation de circuits dans les plus belles villes d\'Égypte. Nous fournissons d\'excellents services et des voyages soigneusement organisés pour vous assurer la meilleure expérience touristique possible.',
            'feature-service': 'Excellent service client',
            'feature-safety': 'Circuits sûrs et sécurisés',
            'feature-guides': 'Guides touristiques professionnels',
            'feature-timing': 'Ponctuel et organisé',
            
            // Sections
            'hurghada-title': 'Circuits Hurghada',
            'hurghada-subtitle': 'Profitez d\'aventures incroyables en mer Rouge',
            'luxor-title': 'Circuits Luxor',
            'luxor-subtitle': 'Découvrez les trésors pharaoniques de l\'Égypte',
            'cairo-title': 'Circuits Le Caire',
            'cairo-subtitle': 'Découvrez les merveilles de l\'Égypte ancienne',
            
            // Tours
            'tour-hula-hula-name': 'Excursion île Hula Hula',
            'tour-hula-hula-time': '8h30 - 16h30',
            'tour-hula-hula-desc': 'Découvrez les Maldives égyptiennes avec des eaux cristallines et des plages dorées avec des spots photo professionnels',
            'tour-hula-hula-h1': 'Deux arrêts de plongée avec tuba',
            'tour-hula-hula-h2': 'Exploration de l\'île',
            'tour-hula-hula-h3': 'Déjeuner complet inclus',
            'tour-hula-hula-h4': 'Gilets de sauvetage disponibles',
            
            'book-now': 'Réserver maintenant',
            
            // Contact Section
            'contact-title': 'Contactez-nous',
            'contact-subtitle': 'Nous sommes là pour vous aider à planifier le voyage de vos rêves',
            'contact-whatsapp': 'WhatsApp',
            'contact-email': 'E-mail',
            'contact-phone': 'Téléphone',
            'form-name': 'Votre nom complet',
            'form-email': 'Adresse e-mail',
            'form-phone': 'Numéro de téléphone',
            'form-message': 'Votre message ou demande',
            'form-submit': 'Envoyer le message',
            
            // Footer
            'footer-links': 'Liens rapides',
            'footer-social': 'Suivez-nous',
            'footer-copyright': '© 2025 Egypt Essence Tours. Tous droits réservés.',
            
            // WhatsApp Messages
            'whatsapp-general': 'Bonjour! J\'aimerais me renseigner sur vos circuits',
            'whatsapp-contact-form': 'Bonjour! Je m\'appelle {name}, e-mail: {email}, téléphone: {phone}. Message: {message}'
        }
    };

    // Language configuration with auto-detection
    const languageConfig = {
        ar: { dir: 'rtl', name: 'العربية', flag: '🇪🇬' },
        en: { dir: 'ltr', name: 'English', flag: '🇬🇧' },
        de: { dir: 'ltr', name: 'Deutsch', flag: '🇩🇪' },
        ru: { dir: 'ltr', name: 'Русский', flag: '🇷🇺' },
        zh: { dir: 'ltr', name: '中文', flag: '🇨🇳' },
        cs: { dir: 'ltr', name: 'Čeština', flag: '🇨🇿' },
        fr: { dir: 'ltr', name: 'Français', flag: '🇫🇷' }
    };

    let currentLanguage = 'ar';
    const whatsappNumber = '201009531706'; // Updated number

    // Enhanced Language Detection Function
    function detectLanguage() {
        // Check for saved preference first
        const savedLang = localStorage.getItem('preferred-language');
        if (savedLang && languageConfig[savedLang]) {
            console.log(`Found saved language: ${savedLang}`);
            return savedLang;
        }

        // Comprehensive browser language detection
        const browserLanguages = [];
        
        // Primary language
        if (navigator.language) {
            browserLanguages.push(navigator.language.toLowerCase());
        }
        
        // All preferred languages
        if (navigator.languages && navigator.languages.length > 0) {
            navigator.languages.forEach(lang => {
                browserLanguages.push(lang.toLowerCase());
            });
        }
        
        // System language (if available)
        if (navigator.userLanguage) {
            browserLanguages.push(navigator.userLanguage.toLowerCase());
        }
        
        if (navigator.browserLanguage) {
            browserLanguages.push(navigator.browserLanguage.toLowerCase());
        }
        
        if (navigator.systemLanguage) {
            browserLanguages.push(navigator.systemLanguage.toLowerCase());
        }

        console.log('Detected browser languages:', browserLanguages);
        
        // Language mapping with priority
        for (let browserLang of browserLanguages) {
            // Exact matches
            if (browserLang === 'ar' || browserLang.startsWith('ar-')) return 'ar';
            if (browserLang === 'en' || browserLang.startsWith('en-')) return 'en';
            if (browserLang === 'de' || browserLang.startsWith('de-')) return 'de';
            if (browserLang === 'ru' || browserLang.startsWith('ru-')) return 'ru';
            if (browserLang === 'zh' || browserLang.startsWith('zh-')) return 'zh';
            if (browserLang === 'cs' || browserLang.startsWith('cs-')) return 'cs';
            if (browserLang === 'fr' || browserLang.startsWith('fr-')) return 'fr';
        }
        
        // Default to Arabic if no supported language detected
        console.log('No supported language detected, defaulting to Arabic');
        return 'ar';
    }

    // Apply Language Function
    function applyLanguage(lang) {
        currentLanguage = lang;
        const config = languageConfig[lang];
        
        console.log(`Applying language: ${lang} (${config.name})`);
        
        // Update document attributes
        document.documentElement.lang = lang;
        document.body.setAttribute('data-lang', lang);
        document.body.setAttribute('data-dir', config.dir);
        
        // Update page title and meta description
        document.title = translations[lang]['page-title'];
        const metaDesc = document.querySelector('meta[name="description"]');
        if (metaDesc) {
            metaDesc.setAttribute('content', translations[lang]['page-description']);
        }
        
        // Update all translatable elements
        const translatableElements = document.querySelectorAll('[data-translate]');
        translatableElements.forEach(element => {
            const key = element.getAttribute('data-translate');
            if (translations[lang][key]) {
                if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                    element.placeholder = translations[lang][key];
                } else {
                    element.textContent = translations[lang][key];
                }
            }
        });

        // Update language switcher current display
        const currentLangBtn = document.getElementById('currentLang');
        if (currentLangBtn) {
            const langSpan = currentLangBtn.querySelector('span');
            if (langSpan) {
                langSpan.textContent = config.name;
            }
        }

        // Update active language in dropdown
        const langLinks = document.querySelectorAll('.language-dropdown a');
        langLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('data-lang') === lang) {
                link.classList.add('active');
            }
        });

        // Save to localStorage
        localStorage.setItem('preferred-language', lang);
        
        // Update WhatsApp float button with new message
        updateWhatsAppFloat();
    }

    // WhatsApp Message Generator
    function generateWhatsAppMessage(tourName, lang = currentLanguage) {
        const message = translations[lang]['whatsapp-general'];
        return encodeURIComponent(message);
    }

    // Update WhatsApp float button
    function updateWhatsAppFloat() {
        const existingFloat = document.querySelector('.whatsapp-float');
        if (existingFloat) {
            const message = generateWhatsAppMessage('general');
            existingFloat.href = `https://wa.me/${whatsappNumber}?text=${message}`;
            existingFloat.title = translations[currentLanguage]['contact-whatsapp'];
        }
    }

    // Initialize Language System
    function initLanguageSystem() {
        const detectedLang = detectLanguage();
        console.log(`Detected language: ${detectedLang}`);
        applyLanguage(detectedLang);

        // Language switcher functionality
        const languageBtn = document.getElementById('currentLang');
        const languageDropdown = document.getElementById('languageDropdown');

        if (languageBtn && languageDropdown) {
            languageBtn.addEventListener('click', function(e) {
                e.preventDefault();
                languageDropdown.classList.toggle('active');
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!languageBtn.contains(e.target) && !languageDropdown.contains(e.target)) {
                    languageDropdown.classList.remove('active');
                }
            });

            // Language selection
            const langLinks = languageDropdown.querySelectorAll('a');
            langLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const selectedLang = this.getAttribute('data-lang');
                    
                    // Smooth transition effect
                    document.body.classList.add('fade-transition');
                    document.body.classList.add('fade-out');
                    
                    setTimeout(() => {
                        applyLanguage(selectedLang);
                        languageDropdown.classList.remove('active');
                        
                        document.body.classList.remove('fade-out');
                        setTimeout(() => {
                            document.body.classList.remove('fade-transition');
                        }, 150);
                    }, 150);
                });
            });
        }
    }

    // Mobile Menu Toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navList = document.querySelector('.nav-list');
    
    if (mobileMenuToggle && navList) {
        mobileMenuToggle.addEventListener('click', function() {
            navList.classList.toggle('active');
            
            const icon = this.querySelector('i');
            if (navList.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });

        // Close mobile menu when clicking on a link
        const navLinks = document.querySelectorAll('.nav-list a');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                navList.classList.remove('active');
                const icon = mobileMenuToggle.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            });
        });
    }

    // Smooth Scrolling
    const scrollLinks = document.querySelectorAll('a[href^="#"]');
    
    scrollLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetElement.offsetTop - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Header Background on Scroll
    const header = document.querySelector('.header');
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
            header.style.background = 'linear-gradient(135deg, rgba(8, 51, 66, 0.95) 0%, rgba(27, 200, 210, 0.95) 100%)';
            header.style.backdropFilter = 'blur(10px)';
        } else {
            header.style.background = 'linear-gradient(135deg, #083342 0%, #1bc8d2 100%)';
            header.style.backdropFilter = 'none';
        }
    });

    // WhatsApp Booking Integration
    function initBookingButtons() {
        const bookButtons = document.querySelectorAll('.book-btn');
        
        bookButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Click animation
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = 'scale(1.05)';
                    setTimeout(() => {
                        this.style.transform = '';
                    }, 150);
                }, 100);
                
                const tourName = this.getAttribute('data-tour-name') || 'general';
                const message = generateWhatsAppMessage(tourName);
                const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${message}`;
                
                // Open WhatsApp
                window.open(whatsappUrl, '_blank');
                
                // Track booking attempt
                console.log(`Booking clicked for: ${tourName} in ${currentLanguage}`);
            });
        });
    }

    // Contact Form Handling
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const name = formData.get('name').trim();
            const email = formData.get('email').trim();
            const phone = formData.get('phone').trim();
            const message = formData.get('message').trim();
            
            // Validation
            if (!name || !email || !phone || !message) {
                showNotification('Please fill all fields', 'error');
                return;
            }

            // Create WhatsApp message with form data
            const whatsappMessage = translations[currentLanguage]['whatsapp-contact-form']
                .replace('{name}', name)
                .replace('{email}', email)
                .replace('{phone}', phone)
                .replace('{message}', message);
            
            const encodedMessage = encodeURIComponent(whatsappMessage);
            const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;
            
            // Show success message
            showSuccessMessage();
            
            // Open WhatsApp
            setTimeout(() => {
                window.open(whatsappUrl, '_blank');
            }, 1500);
            
            // Reset form
            setTimeout(() => {
                this.reset();
            }, 2000);
        });
    }

    // Success message function
    function showSuccessMessage() {
        const existingMessage = document.querySelector('.success-message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        const successDiv = document.createElement('div');
        successDiv.className = 'success-message show';
        
        const successMessages = {
            ar: 'تم إرسال رسالتك بنجاح! سيتم تحويلك إلى الواتساب...',
            en: 'Message sent successfully! Redirecting to WhatsApp...',
            de: 'Nachricht erfolgreich gesendet! Weiterleitung zu WhatsApp...',
            ru: 'Сообщение успешно отправлено! Перенаправление в WhatsApp...',
            zh: '消息发送成功！正在重定向到WhatsApp...',
            cs: 'Zpráva úspěšně odeslána! Přesměrování na WhatsApp...',
            fr: 'Message envoyé avec succès! Redirection vers WhatsApp...'
        };
        
        successDiv.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>${successMessages[currentLanguage]}</span>
        `;
        
        contactForm.appendChild(successDiv);
        
        setTimeout(() => {
            if (successDiv) {
                successDiv.remove();
            }
        }, 5000);
    }

    // Notification system
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'error' ? '#dc3545' : '#28a745'};
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            z-index: 10000;
            font-weight: 500;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    // Active navigation highlighting
    function initNavHighlighting() {
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('.nav-list a[href^="#"]');

        window.addEventListener('scroll', function() {
            const currentScroll = window.pageYOffset + 100;

            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.offsetHeight;
                const sectionId = section.getAttribute('id');

                if (currentScroll >= sectionTop && currentScroll < sectionTop + sectionHeight) {
                    navLinks.forEach(link => {
                        link.classList.remove('active');
                        if (link.getAttribute('href') === `#${sectionId}`) {
                            link.classList.add('active');
                        }
                    });
                }
            });
        });
    }

    // WhatsApp Float Button
    function loadWhatsAppFloat() {
        const whatsappFloat = document.createElement('div');
        const message = generateWhatsAppMessage('general');
        whatsappFloat.innerHTML = `
            <a href="https://wa.me/${whatsappNumber}?text=${message}" 
               target="_blank" 
               class="whatsapp-float"
               title="${translations[currentLanguage]['contact-whatsapp']}">
                <i class="fab fa-whatsapp"></i>
            </a>
        `;
        document.body.appendChild(whatsappFloat);
        
        const floatButton = whatsappFloat.querySelector('.whatsapp-float');
        floatButton.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.1)';
            this.style.boxShadow = '0 6px 16px rgba(37, 211, 102, 0.6)';
        });
        
        floatButton.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
            this.style.boxShadow = '0 4px 12px rgba(37, 211, 102, 0.4)';
        });
    }

    // Animation Observer
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Initialize animations
    function initAnimations() {
        const tourCards = document.querySelectorAll('.tour-card');
        tourCards.forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(card);
        });

        // Enhanced hover effects
        tourCards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-8px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });
    }

    // Initialize everything
    function init() {
        console.log('Egypt Essence Tours - Initializing multilingual website...');
        
        initLanguageSystem();
        initBookingButtons();
        initAnimations();
        initNavHighlighting();
        
        // Load WhatsApp float after a delay
        setTimeout(loadWhatsAppFloat, 2000);
        
        // Mark page as loaded
        window.addEventListener('load', function() {
            document.body.classList.add('page-loaded');
        });
        
        console.log('Egypt Essence Tours multilingual website loaded successfully! 🏺✨');
        console.log(`Current language: ${currentLanguage} (${languageConfig[currentLanguage].name})`);
        console.log(`WhatsApp number: +${whatsappNumber}`);
        console.log('Supported languages:', Object.keys(languageConfig).map(k => `${k} (${languageConfig[k].name})`));
    }

    // Start the application
    init();
});